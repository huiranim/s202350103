package com.choongang.s202350103.hrDao;

import com.choongang.s202350103.model.NewBook;

public interface NewbookDao {

	NewBook selectNewbook(int nb_num);

}
