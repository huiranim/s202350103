package com.choongang.s202350103;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S202350103Application {

	public static void main(String[] args) {
		SpringApplication.run(S202350103Application.class, args);
	}

}
