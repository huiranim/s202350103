package com.choongang.s202350103.htDao;

import com.choongang.s202350103.model.Review;

public interface OrderrDao {
	int      orderTotal();
}
