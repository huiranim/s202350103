package com.choongang.s202350103.hrService;

import com.choongang.s202350103.model.NewBook;

public interface NewbookService {

	NewBook selectNewbook(int nb_num);
	
}
