package com.choongang.s202350103.htService;

import com.choongang.s202350103.model.Review;

public interface OrderrService {
	
	int        orderTotal();
}
